#include <stdio.h>
#include <stdlib.h>

typedef struct Usuario{
  struct playlist* playlist;
  struct playlist* next;
}usuario;

typedef struct Podcast {
	int id;
	char nome[60];
	struct ep* ep;
  struct Podcast* next;
}podcast;

typedef struct ep {
	int id;
	char nome[60];
	struct ep* next;
}ep;

typedef struct Playlist {
  int id;
	char nome[60];
	podcast* podcast;
	int quantidade;
}playlist;

void criarPlaylist();
void add(playlist* base);
void remover(playlist* playlist);
void imprimeRecursiva(playlist* base);
void imprimeEP(ep* ep);
void ordenarEP(playlist* playlist);
char tocarPodcast(playlist* playlist);

int main() {
  usuario* USU = (usuario*)malloc(sizeof(usuario));
	playlist* base = (playlist*)malloc(sizeof(playlist));
	base->podcast = NULL;
	base->quantidade = 0;
	int escolha;
printf("\nNomeie sua primeira playlist\n");
  scanf("%s",&base->nome,60);
  USU->playlist = base;
  
	do {
		printf("\n Podcast: %s\n\n  MENU\n",base->nome);
		printf("  1 - Mostrar EPS  \n");
		printf("  2 - Adicionar   \n");
		printf("  3 - remover   \n");
    printf("  4 - Tocar EP     \n");
		printf("   0 - Sair     \n");
		printf("\n\nEntre com a opcao desejada: ");
		scanf("%d", &escolha);

		switch (escolha)
		{
  case 0:

      break;
		case 1:
      if(base->podcast != NULL)
			imprimeRecursiva(base);
			break;
      	case 2:
		    	add(base);
		    	break;
            case 3:
              imprimeRecursiva(base);
              remover(base);
              break;
      	        case 4:
            if(base->podcast != NULL){
              printf("\nEscolha um dos eps da sua playlist:\n");   
           	imprimeRecursiva(base);
			      tocarPodcast(base);
              }
		      	break;
		}

	} while (escolha);

	return 0;
}

void criarPlaylist(playlist* playlistUsu){
  playlist* nova = (playlist*)malloc(sizeof(playlist));
printf("Nome da playlits:");
  scanf("%s",nova->nome,60);
} 

void add(playlist* base) {
 if(base->podcast == NULL){
     podcast* cabecapod = (podcast*)malloc(sizeof(podcast));
    base->podcast = cabecapod;
 }
  if(base->podcast->ep == NULL){
  ep* cabeca = (ep*)malloc(sizeof(ep));
    base->podcast->ep = cabeca;
  }
	ep* novo = (ep*)malloc(sizeof(ep));
	novo->next = NULL;
	printf("\nDigite o ep: ");
	  scanf("%s", &novo->nome, 60);
  
  if(base->podcast->ep->next == NULL){
    base->podcast->ep->next = novo; 
    return;}
    novo->next = base->podcast->ep->next;
   base->podcast->ep->next =novo;
}

void remover(playlist* playlist){
if(playlist->podcast->ep->next == NULL)return;
 ep* anterior = (ep*)malloc(sizeof(ep));
  ep* proximo = (ep*)malloc(sizeof(ep));
  int remover;
  printf("\nDigite o id que deseja remover:");
  scanf("%d",&remover);
  anterior = playlist->podcast->ep;
  proximo = anterior->next;
  
  while(proximo != NULL){
    if(proximo->id == remover){
      anterior->next = proximo->next;
      return;
    }
    anterior = proximo;
    proximo = proximo->next;
  }
}

char tocarPodcast(playlist* playlist){
ep* comeco = (ep*)malloc(sizeof(ep));
  comeco = playlist->podcast->ep->next;
  int escolha;
  
  printf("\nDigite o id do ep:");
    scanf("%d",&escolha);
  
  int continuar = 1;
  while(comeco != NULL){

    if(comeco->id == escolha){
      printf("\n\nTocando [%d] %s\n\n0 - PARAR\n1 - Continuar\n",comeco->id,comeco->nome);
      if(comeco->next != NULL)
     printf("Proximo ep [%d] %s\n",comeco->next->id,comeco->next->nome);
      else return scanf("%d",&continuar);
      scanf("%d",&continuar);
      if(continuar == 0) return 0;
      else if(continuar != 0&& continuar != 1)
              return printf("\n(ERRO:Valor inválido)");
      
if(continuar == 1&& comeco->next->next != NULL) escolha++;
      else {
     printf("\nULTIMO EP\nTocando [%d] %s\nPrecione qualquer tecla numero\n",comeco->next->id,comeco->next->nome);
      scanf("%d",&continuar);
        return 0;
      }
     }   
    comeco = comeco->next;
  }
  return printf("\nID [%d] não encontrado",escolha);
}


void imprimeRecursiva(playlist* base) {
	if (base->podcast->ep->next != NULL) {
    ordenarEP(base);
		imprimeEP(base->podcast->ep->next);
	}
  else printf("Playlist vazia");
}
void ordenarEP(playlist* playlist){
ep* comeco = (ep*)malloc(sizeof(ep));
  comeco = playlist->podcast->ep->next;
     int quantidade = 0; 
  while(comeco != NULL){
            quantidade++;
            comeco->id = quantidade;
            comeco = comeco->next;
    }
}

void imprimeEP(ep* ep) {
  	if (ep->next != NULL) 
    imprimeEP(ep->next);
	printf("\n [%d] %s", ep->id, ep->nome);
}
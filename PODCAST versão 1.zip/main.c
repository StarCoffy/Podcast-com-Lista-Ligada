#include <stdio.h>
#include <stdlib.h>

typedef struct Podcast {
	int id;
	char nome[60];
	struct Podcast* next;
	struct Podcast* ini;
}podcast;

typedef struct Playlist {
	podcast* podcast;
	int quantidade;
}playlist;

void add(playlist* base);
void imprimeRecursiva(playlist* base);
void imprimePodcast(podcast* podcast);
char tocarPodcast(playlist* playlist);
int main() {
	playlist* base = (playlist*)malloc(sizeof(playlist));
	base->podcast = NULL;
	base->quantidade = 0;

	int escolha;

	do {
		printf("\n\n  MENU\n");
		printf("  1 - Mostrar Podcasts  \n");
		printf("  2 - Adicionar   \n");
    printf("  4 - TocarPodcast     \n");
		printf("   0 - Sair     \n");
		printf("\n");
		printf("Entre com a opcao desejada: ");
		scanf("%d", &escolha);

		switch (escolha)
		{
		case 1:
			imprimeRecursiva(base);
			break;
      	case 2:
		    	add(base);
		    	break;
      	  case 4:
            if(base->podcast != NULL){
       printf("\nEscolha um dos podcasts da sua playlist:\n");
           	imprimeRecursiva(base);
			      tocarPodcast(base);
              }
		      	break;
		}

	} while (escolha);

	return 0;
}

void add(playlist* base) {
 
  if(base->podcast == NULL){
  podcast* cabeca = (podcast*)malloc(sizeof(podcast));
    base->podcast = cabeca;
  }
	podcast* novo = (podcast*)malloc(sizeof(podcast));
	novo->next = NULL;
	novo->ini = NULL;
  base->quantidade = base->quantidade + 1;
	novo->id = base->quantidade;
	printf("\nDigite o podcast: ");
	  scanf("%s", &novo->nome, 60);
  
  if(base->podcast->next == NULL){
    base->podcast->next = novo; 
    return;}
    novo->next = base->podcast->next;
   base->podcast->next =novo;
}

char tocarPodcast(playlist* playlist){
podcast* comeco = (podcast*)malloc(sizeof(podcast));
  comeco = playlist->podcast;
  int escolha;
  
  printf("\nDigite o id do podcast:");
    scanf("%d",&escolha);
  
  int continuar;
  while(comeco != NULL){
    if(comeco->id == escolha){
      printf("\nTocando [%d] %s\n\nPara parar de ouvir digite 0\n",comeco->id,comeco->nome);
      scanf("%d",&continuar);
      
      return 0;
     }
    comeco = comeco->next;
  }
  return printf("\nID [%d] não encontrado",escolha);
}


void imprimeRecursiva(playlist* base) {
	if (base->podcast != NULL) {
		imprimePodcast(base->podcast->next);
	}
  else printf("Playlist vazia");
}

void imprimePodcast(podcast* podcast) {
  	if (podcast->next != NULL) 
    imprimePodcast(podcast->next);
	printf("\n [%d] %s", podcast->id, podcast->nome);
}
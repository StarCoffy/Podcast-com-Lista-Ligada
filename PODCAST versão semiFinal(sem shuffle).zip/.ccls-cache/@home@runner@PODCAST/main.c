#include <stdio.h>
#include <stdlib.h>

typedef struct Podcast {
	int id;
	char nome[60];
  int quantidade;
	struct ep* ep;
  struct Podcast* next;
}podcast;

typedef struct ep {
	int id;
	char nome[60];
	struct ep* next;
}ep;

typedef struct Playlist {
  int id;
	char nome[60];
	podcast* podcast;
	int quantidade;
}playlist;

void criarPlaylist();
void addPOD(playlist*base);
void add(podcast* podcast);
void remover(podcast* podcast);
void removerPOD(playlist* playlist);
void imprimePOD(playlist*base);
void imprimeRecursiva(podcast* base);
void imprimeEP(ep* ep);
void ordenarEP(podcast* playlist);
char tocarEP(podcast* playlist);

int main() {

	playlist* base = (playlist*)malloc(sizeof(playlist));
	  podcast* cabecapod = (podcast*)malloc(sizeof(podcast));
    podcast* podAtual = (podcast*)malloc(sizeof(podcast));
    podAtual = NULL;
    base->podcast = cabecapod;
	  base->quantidade = 0;
	int escolha;
printf("\nNomeie sua primeira playlist\n");
  scanf("%s",&base->nome,60);
  ini:
  	do {
		printf("\n\n playlist: %s\n quantidade de podcasts: %d\n  MENU\n",base->nome,base->quantidade);
		printf("  1 - Mostrar Podcasts  \n");
		printf("  2 - Adicionar   \n");
		printf("  3 - remover   \n");
    printf("  4 - Entrar no podcast     \n");
		printf("   0 - Sair     \n");
		printf("\n\nEntre com a opcao desejada: ");
		scanf("%d", &escolha);

		switch (escolha)
		{
  case 0:
      break;
		case 1:
      imprimePOD(base);
			break;
      	case 2:
          addPOD(base);
		    	break;
            case 3:
              imprimePOD(base);
              removerPOD(base);
              break;
      	        case 4:
                  imprimePOD(base);
              podcast* aux = (podcast*)malloc(sizeof(podcast));
                  aux = base->podcast->next;
                    int escolhaPOD;
                    if(base->podcast->next != NULL){
                    printf("\nDigite o id do podcast:");
                    scanf("%d",&escolhaPOD);
                      }
                  while( aux != NULL){
                    if(aux->id == escolhaPOD)
                    {podAtual = aux;escolha = 0;}
                    aux = aux->next;
                  }
                  free(aux);
		      	break;
		}

	} while (escolha);

if(podAtual != NULL)
	do {
		printf("\n\n Podcast: %s\n\n  MENU\n",podAtual->nome);
		printf("  1 - Mostrar EPS  \n");
		printf("  2 - Adicionar   \n");
		printf("  3 - remover   \n");
    printf("  4 - Tocar EP     \n");
    printf("  5 - Escolher outro podcast\n");
		printf("   0 - Sair     \n");
		printf("\n\nEntre com a opcao desejada: ");
		scanf("%d", &escolha);

		switch (escolha)
		{
  case 0:
      break;
		case 1:
			imprimeRecursiva(podAtual);
			break;
      	case 2:
		    	add(podAtual);
		    	break;
            case 3:
              imprimeRecursiva(podAtual);
              if(podAtual->ep != NULL)
              remover(podAtual);
              break;
      	        case 4:
            if(podAtual->ep != NULL){
              printf("\nEscolha um dos eps da sua playlist:\n");   
           	imprimeRecursiva(podAtual);
			      tocarEP(podAtual);
              }
		      	break;
                case 5:
                  goto ini;
                  break;
		}

	} while (escolha);
  
	return 0;
}

void addPOD(playlist*base){
    if(base->podcast == NULL){
  podcast* cabeca = (podcast*)malloc(sizeof(podcast));
    base->podcast = cabeca;
  }
	podcast* novo = (podcast*)malloc(sizeof(podcast));
	novo->next = NULL;
	printf("\nDigite o podcast: ");
	  scanf("%s", &novo->nome, 60);
  
  if(base->podcast->next == NULL){
    base->podcast->next = novo; 
    imprimePOD(base);
    return;}
    novo->next = base->podcast->next;
    base->podcast->next =novo;
  imprimePOD(base);
}

void add(podcast* podcast) {

  if(podcast->ep == NULL){
  ep* cabeca = (ep*)malloc(sizeof(ep));
    podcast->ep = cabeca;
  }
	ep* novo = (ep*)malloc(sizeof(ep));
	novo->next = NULL;
	printf("\nDigite o ep: ");
	  scanf("%s", &novo->nome, 60);
  
  if(podcast->ep->next == NULL){
    podcast->ep->next = novo; 
    return;}
    novo->next = podcast->ep->next;
   podcast->ep->next =novo;
}

void removerPOD(playlist* playlist){
if(playlist->podcast->next == NULL){return;}
  
 podcast* anterior = (podcast*)malloc(sizeof(podcast));
  podcast* proximo = (podcast*)malloc(sizeof(podcast));
  int remover;
  printf("\nDigite o id que deseja remover:");
  scanf("%d",&remover);
  anterior = playlist->podcast;
  proximo = anterior->next;
  
  while(proximo != NULL){
    if(proximo->id == remover){
      anterior->next = proximo->next;
      return;
    }
    anterior = proximo;
    proximo = proximo->next;
  }
}

void remover(podcast* podcast){
if(podcast->ep->next == NULL)return;
 ep* anterior = (ep*)malloc(sizeof(ep));
  ep* proximo = (ep*)malloc(sizeof(ep));
  int remover;
  printf("\nDigite o id que deseja remover:");
  scanf("%d",&remover);
  anterior = podcast->ep;
  proximo = anterior->next;
  
  while(proximo != NULL){
    if(proximo->id == remover){
      anterior->next = proximo->next;
      return;
    }
    anterior = proximo;
    proximo = proximo->next;
  }
}

char tocarEP(podcast* podcast){
ep* comeco = (ep*)malloc(sizeof(ep));
  comeco = podcast->ep->next;
  int escolha;
  
  printf("\nDigite o id do ep:");
    scanf("%d",&escolha);
  
  int continuar = 1;
  while(comeco != NULL){

    if(comeco->id == escolha){
      printf("\n\nTocando [%d] %s\n\n0 - PARAR\n1 - Continuar\n",comeco->id,comeco->nome);
      if(comeco->next != NULL)
     printf("Proximo ep [%d] %s\n",comeco->next->id,comeco->next->nome);
      else return scanf("%d",&continuar);
      scanf("%d",&continuar);
      if(continuar == 0) return 0;
      else if(continuar != 0&& continuar != 1)
              return printf("\n(ERRO:Valor inválido)");
      
if(continuar == 1&& comeco->next->next != NULL) escolha++;
      else {
     printf("\nULTIMO EP\nTocando [%d] %s\nPrecione qualquer tecla numerica\n",comeco->next->id,comeco->next->nome);
      scanf("%d",&continuar);
        return 0;
      }
     }   
    comeco = comeco->next;
  }
  return printf("\nID [%d] não encontrado",escolha);
}

void imprimePOD(playlist*base){
if(base->podcast->next == NULL)
{printf("Playlist Vazia"); return;}
  
  int quantidade = 0;
  podcast* pod = (podcast*)malloc(sizeof(podcast));
  pod = base->podcast->next;
  while(pod != NULL){
    quantidade++;
    base->quantidade = quantidade;
    pod->id = quantidade;
    printf("\n[%d]Podcast - %s",pod->id,pod->nome);
    pod = pod->next;
  }
}

void imprimeRecursiva(podcast* base) {
	if (base->ep != NULL) {
    ordenarEP(base);
		imprimeEP(base->ep->next);
	}
  else printf("Playlist vazia");
}

void ordenarEP(podcast* podcast){
ep* comeco = (ep*)malloc(sizeof(ep));
  comeco = podcast->ep->next;
     int quantidade = 0; 
  while(comeco != NULL){
            quantidade++;
            podcast->quantidade++;
            comeco->id = quantidade;
            comeco = comeco->next;
    }
}

void imprimeEP(ep* ep) {
  	if (ep->next != NULL) 
    imprimeEP(ep->next);
	printf("\n [%d] %s", ep->id, ep->nome);
}

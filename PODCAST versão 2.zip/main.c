#include <stdio.h>
#include <stdlib.h>

typedef struct Usuario{
  struct playlist* playlist;
  struct playlist* next;
}usuario;

typedef struct Podcast {
	int id;
	char nome[60];
	struct Podcast* next;
	struct Podcast* ini;
}podcast;

typedef struct Playlist {
  int id;
	char nome[60];
	podcast* podcast;
	int quantidade;
}playlist;

void criarPlaylist();
void add(playlist* base);
void remover(playlist* playlist);
void imprimeRecursiva(playlist* base);
void imprimePodcast(podcast* podcast);
char tocarPodcast(playlist* playlist);

int main() {
  usuario* USU = (usuario*)malloc(sizeof(usuario));
	playlist* base = (playlist*)malloc(sizeof(playlist));
	base->podcast = NULL;
	base->quantidade = 0;
	int escolha;
printf("\nNomeie sua primeira playlist\n");
  scanf("%s",&base->nome,60);
  USU->playlist = base;
  
	do {
		printf("\n\nPlaylist %s\n\n  MENU\n",base->nome);
		printf("  1 - Mostrar Podcasts  \n");
		printf("  2 - Adicionar   \n");
		printf("  3 - remover   \n");
    printf("  4 - TocarPodcast     \n");
		printf("   0 - Sair     \n");
		printf("\n\nEntre com a opcao desejada: ");
		scanf("%d", &escolha);

		switch (escolha)
		{
  case 0:

      break;
		case 1:
			imprimeRecursiva(base);
			break;
      	case 2:
		    	add(base);
		    	break;
            case 3:
              imprimeRecursiva(base);
              remover(base);
              break;
      	        case 4:
            if(base->podcast != NULL){
             printf("\nEscolha um dos podcasts da sua                playlist:\n");
           	imprimeRecursiva(base);
			      tocarPodcast(base);
              }
		      	break;
		}

	} while (escolha);

	return 0;
}

void criarPlaylist(playlist* playlistUsu){
  playlist* nova = (playlist*)malloc(sizeof(playlist));
printf("Nome da playlits:");
  scanf("%s",nova->nome,60);
} 

void add(playlist* base) {
 
  if(base->podcast == NULL){
  podcast* cabeca = (podcast*)malloc(sizeof(podcast));
    base->podcast = cabeca;
  }
	podcast* novo = (podcast*)malloc(sizeof(podcast));
	novo->next = NULL;
	novo->ini = NULL;
  base->quantidade = base->quantidade + 1;
	novo->id = base->quantidade;
	printf("\nDigite o podcast: ");
	  scanf("%s", &novo->nome, 60);
  
  if(base->podcast->next == NULL){
    base->podcast->next = novo; 
    return;}
    novo->next = base->podcast->next;
   base->podcast->next =novo;
}

void remover(playlist* playlist){
if(playlist->podcast->next == NULL)return;
 podcast* anterior = (podcast*)malloc(sizeof(podcast));
  podcast* proximo = (podcast*)malloc(sizeof(podcast));
  int remover;
  printf("\nDigite o id que deseja remover:");
  scanf("%d",&remover);
  anterior = playlist->podcast;
  proximo = anterior->next;
  
  while(proximo != NULL){
    if(proximo->id == remover){
      anterior->next = proximo->next;
      return;
    }
    anterior = proximo;
    proximo = proximo->next;
  }
}

char tocarPodcast(playlist* playlist){
podcast* comeco = (podcast*)malloc(sizeof(podcast));
  comeco = playlist->podcast;
  int escolha;
  
  printf("\nDigite o id do podcast:");
    scanf("%d",&escolha);
  
  int continuar = 1;
  while(comeco != NULL){

    if(comeco->id == escolha){
      printf("\nTocando [%d] %s\n\n0 - PARAR\n",comeco->id,comeco->nome);
      scanf("%d",&continuar);
    
      if(continuar == 0) return 0;
      else if(continuar != 0&& continuar != 1)
              return printf("\n(ERRO:Valor inválido)");
      
      if(continuar == 1) escolha = escolha + 1;
      }   
    comeco = comeco->next;
//        if(comeco == NULL) 
//            return printf("Próximo não encontrado");
  }
  return printf("\nID [%d] não encontrado",escolha);
}


void imprimeRecursiva(playlist* base) {
	if (base->podcast->next != NULL) {
		imprimePodcast(base->podcast->next);
	}
  else printf("Playlist vazia");
}

void imprimePodcast(podcast* podcast) {
  	if (podcast->next != NULL) 
    imprimePodcast(podcast->next);
	printf("\n [%d] %s", podcast->id, podcast->nome);
}